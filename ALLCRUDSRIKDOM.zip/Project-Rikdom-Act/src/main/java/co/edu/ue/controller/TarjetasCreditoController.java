package co.edu.ue.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import co.edu.ue.entity.TarjetasCredito;
import co.edu.ue.service.ITarjetasCreditoService;

@RestController
@RequestMapping("/tarjetas-credito")
public class TarjetasCreditoController {

    @Autowired
    private ITarjetasCreditoService service;

    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<TarjetasCredito>> addTarjetaCredito(@RequestBody TarjetasCredito tarjetaCredito) {
        return new ResponseEntity<>(service.addTarjetaCredito(tarjetaCredito), HttpStatus.CREATED);
    }

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<TarjetasCredito>> getAllTarjetasCredito() {
        return new ResponseEntity<>(service.getAllTarjetasCredito(), HttpStatus.OK);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TarjetasCredito> getTarjetaCreditoById(@PathVariable("id") int id) {
        return new ResponseEntity<>(service.findById(id), HttpStatus.OK);
    }

    @PutMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TarjetasCredito> updateTarjetaCredito(@RequestBody TarjetasCredito tarjetaCredito) {
        return new ResponseEntity<>(service.updateTarjetaCredito(tarjetaCredito), HttpStatus.ACCEPTED);
    }
}