package co.edu.ue.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "clientes")
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cli_id")
    private int cliId;

    @Column(name = "cli_document")
    private String cliDocument;

    @Column(name = "cli_nombres")
    private String cliNombres;

    @Column(name = "cli_apellidos")
    private String cliApellidos;

    @Column(name = "cli_direccion")
    private String cliDireccion;

    @Column(name = "cli_telefono")
    private int cliTelefono;

    @Column(name = "usu_id")
    private int usuId;

    // Getters y setters
    public int getCliId() {
        return cliId;
    }

    public void setCliId(int cliId) {
        this.cliId = cliId;
    }

    public String getCliDocument() {
        return cliDocument;
    }

    public void setCliDocument(String cliDocument) {
        this.cliDocument = cliDocument;
    }

    public String getCliNombres() {
        return cliNombres;
    }

    public void setCliNombres(String cliNombres) {
        this.cliNombres = cliNombres;
    }

    public String getCliApellidos() {
        return cliApellidos;
    }

    public void setCliApellidos(String cliApellidos) {
        this.cliApellidos = cliApellidos;
    }

    public String getCliDireccion() {
        return cliDireccion;
    }

    public void setCliDireccion(String cliDireccion) {
        this.cliDireccion = cliDireccion;
    }

    public int getCliTelefono() {
        return cliTelefono;
    }

    public void setCliTelefono(int cliTelefono) {
        this.cliTelefono = cliTelefono;
    }

    public int getUsuId() {
        return usuId;
    }

    public void setUsuId(int usuId) {
        this.usuId = usuId;
    }
}
