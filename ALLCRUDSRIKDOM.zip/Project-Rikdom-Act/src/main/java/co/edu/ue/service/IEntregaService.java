package co.edu.ue.service;

import java.util.List;
import co.edu.ue.entity.Entrega;

public interface IEntregaService {
    List<Entrega> addEntrega(Entrega entrega);
    Entrega updateEntrega(Entrega entrega);
    List<Entrega> getAllEntregas();
    Entrega findById(int id);
}