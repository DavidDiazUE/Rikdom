package co.edu.ue.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import co.edu.ue.entity.Solicitude;
import co.edu.ue.jpa.ISolicitudeJPA;

@Repository
public class SolicitudeDao implements ISolicitudeDao {

    @Autowired
    private ISolicitudeJPA jpa;

    @Override
    public List<Solicitude> guardarSolicitude(Solicitude solicitude) {
        jpa.save(solicitude);
        return listaCompleta();
    }

    @Override
    public Solicitude actualizarSolicitude(Solicitude solicitude) {
        return jpa.save(solicitude);
    }

    @Override
    public List<Solicitude> listaCompleta() {
        return jpa.findAll();
    }

    @Override
    public Solicitude buscarPorId(int id) {
        return jpa.findById(id).orElse(null);
    }
}