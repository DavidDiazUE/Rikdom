package co.edu.ue.dao;

import java.util.List;
import co.edu.ue.entity.Entrega;

public interface IEntregaDao {
    List<Entrega> guardarEntrega(Entrega entrega);
    Entrega actualizarEntrega(Entrega entrega);
    List<Entrega> listaCompleta();
    Entrega buscarPorId(int id);
}