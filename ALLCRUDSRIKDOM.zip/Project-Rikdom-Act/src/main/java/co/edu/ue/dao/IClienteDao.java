package co.edu.ue.dao;

import java.util.List;
import co.edu.ue.entity.Cliente;

public interface IClienteDao {
    List<Cliente> guardarCliente(Cliente cliente);
    Cliente actualizarCliente(Cliente cliente);
    List<Cliente> listaCompleta();
    Cliente buscarPorId(int id);
}