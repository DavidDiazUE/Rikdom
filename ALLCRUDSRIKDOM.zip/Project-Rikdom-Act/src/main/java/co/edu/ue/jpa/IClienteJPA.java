package co.edu.ue.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import co.edu.ue.entity.Cliente;

public interface IClienteJPA extends JpaRepository<Cliente, Integer> {
}
