package co.edu.ue.service;

import java.util.List;
import co.edu.ue.entity.Solicitude;

public interface ISolicitudeService {
    List<Solicitude> addSolicitude(Solicitude solicitude);
    Solicitude updateSolicitude(Solicitude solicitude);
    List<Solicitude> listAll();
    Solicitude findById(int id);
}