package co.edu.ue.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import co.edu.ue.entity.Solicitude;
import co.edu.ue.service.ISolicitudeService;

@RestController
@RequestMapping("/solicitude")
public class SolicitudeController {

    @Autowired
    private ISolicitudeService service;

    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Solicitude>> addSolicitude(@RequestBody Solicitude solicitude) {
        return new ResponseEntity<>(service.addSolicitude(solicitude), HttpStatus.CREATED);
    }

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Solicitude>> getAllSolicitudes() {
        return new ResponseEntity<>(service.listAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Solicitude> getSolicitudeById(@PathVariable("id") int id) {
        return new ResponseEntity<>(service.findById(id), HttpStatus.OK);
    }

    @PutMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Solicitude> updateSolicitude(@RequestBody Solicitude solicitude) {
        return new ResponseEntity<>(service.updateSolicitude(solicitude), HttpStatus.ACCEPTED);
    }
}
