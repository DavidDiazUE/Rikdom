package co.edu.ue.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.edu.ue.dao.IEntregaDao;
import co.edu.ue.entity.Entrega;

@Service
public class EntregaService implements IEntregaService {

    @Autowired
    private IEntregaDao dao;

    @Override
    public List<Entrega> addEntrega(Entrega entrega) {
        return dao.guardarEntrega(entrega);
    }

    @Override
    public Entrega updateEntrega(Entrega entrega) {
        return dao.actualizarEntrega(entrega);
    }

    @Override
    public List<Entrega> getAllEntregas() {
        return dao.listaCompleta();
    }

    @Override
    public Entrega findById(int id) {
        return dao.buscarPorId(id);
    }
}