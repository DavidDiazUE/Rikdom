package co.edu.ue.service;

import java.util.List;
import co.edu.ue.entity.TarjetasCredito;

public interface ITarjetasCreditoService {
    List<TarjetasCredito> addTarjetaCredito(TarjetasCredito tarjetaCredito);
    TarjetasCredito updateTarjetaCredito(TarjetasCredito tarjetaCredito);
    List<TarjetasCredito> getAllTarjetasCredito();
    TarjetasCredito findById(int id);
}
