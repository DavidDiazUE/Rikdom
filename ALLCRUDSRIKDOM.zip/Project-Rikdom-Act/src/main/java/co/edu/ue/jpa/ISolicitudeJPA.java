package co.edu.ue.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import co.edu.ue.entity.Solicitude;

public interface ISolicitudeJPA extends JpaRepository<Solicitude, Integer> {
}