package co.edu.ue.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.edu.ue.dao.ITarjetasCreditoDao;
import co.edu.ue.entity.TarjetasCredito;

@Service
public class TarjetasCreditoService implements ITarjetasCreditoService {

    @Autowired
    private ITarjetasCreditoDao dao;

    @Override
    public List<TarjetasCredito> addTarjetaCredito(TarjetasCredito tarjetaCredito) {
        return dao.guardarTarjetaCredito(tarjetaCredito);
    }

    @Override
    public TarjetasCredito updateTarjetaCredito(TarjetasCredito tarjetaCredito) {
        return dao.actualizarTarjetaCredito(tarjetaCredito);
    }

    @Override
    public List<TarjetasCredito> getAllTarjetasCredito() {
        return dao.listaCompleta();
    }

    @Override
    public TarjetasCredito findById(int id) {
        return dao.buscarPorId(id);
    }
}
