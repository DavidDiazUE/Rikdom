package co.edu.ue.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.edu.ue.dao.IClienteDao;
import co.edu.ue.entity.Cliente;

@Service
public class ClienteService implements IClienteService {

    @Autowired
    private IClienteDao dao;

    @Override
    public List<Cliente> addCliente(Cliente cliente) {
        return dao.guardarCliente(cliente);
    }

    @Override
    public Cliente updateCliente(Cliente cliente) {
        return dao.actualizarCliente(cliente);
    }

    @Override
    public List<Cliente> listAll() {
        return dao.listaCompleta();
    }

    @Override
    public Cliente findById(int id) {
        return dao.buscarPorId(id);
    }
}