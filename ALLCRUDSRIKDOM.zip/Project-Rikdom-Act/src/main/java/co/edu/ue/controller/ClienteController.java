package co.edu.ue.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import co.edu.ue.entity.Cliente;
import co.edu.ue.service.IClienteService;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private IClienteService service;

    @PostMapping(consumes = "application/json", produces = "application/json")
    public ResponseEntity<List<Cliente>> createCliente(@RequestBody Cliente cliente) {
        List<Cliente> clientes = service.addCliente(cliente);
        return new ResponseEntity<>(clientes, HttpStatus.CREATED);
    }

    @PutMapping(consumes = "application/json", produces = "application/json")
    public ResponseEntity<Cliente> updateCliente(@RequestBody Cliente cliente) {
        Cliente updatedCliente = service.updateCliente(cliente);
        return new ResponseEntity<>(updatedCliente, HttpStatus.OK);
    }

    @GetMapping(produces = "application/json")
    public ResponseEntity<List<Cliente>> getAllClientes() {
        List<Cliente> clientes = service.listAll();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Total-Clientes", String.valueOf(clientes.size()));
        return new ResponseEntity<>(clientes, headers, HttpStatus.OK);
    }

    @GetMapping(value = "/{id}", produces = "application/json")
    public ResponseEntity<Cliente> getClienteById(@PathVariable("id") int id) {
        Cliente cliente = service.findById(id);
        return new ResponseEntity<>(cliente, HttpStatus.OK);
    }
}