package co.edu.ue.dao;

import java.util.List;
import co.edu.ue.entity.Solicitude;

public interface ISolicitudeDao {
    List<Solicitude> guardarSolicitude(Solicitude solicitude);
    Solicitude actualizarSolicitude(Solicitude solicitude);
    List<Solicitude> listaCompleta();
    Solicitude buscarPorId(int id);
}
