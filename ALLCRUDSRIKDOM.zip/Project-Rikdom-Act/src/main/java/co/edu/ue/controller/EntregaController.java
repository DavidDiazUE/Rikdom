// Controller
package co.edu.ue.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import co.edu.ue.entity.Entrega;
import co.edu.ue.service.IEntregaService;

@RestController
@RequestMapping("/entrega")
public class EntregaController {

    @Autowired
    private IEntregaService service;

    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Entrega>> addEntrega(@RequestBody Entrega entrega) {
        return new ResponseEntity<>(service.addEntrega(entrega), HttpStatus.CREATED);
    }

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Entrega>> getAllEntregas() {
        return new ResponseEntity<>(service.getAllEntregas(), HttpStatus.OK);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Entrega> getEntregaById(@PathVariable("id") int id) {
        return new ResponseEntity<>(service.findById(id), HttpStatus.OK);
    }

    @PutMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Entrega> updateEntrega(@RequestBody Entrega entrega) {
        return new ResponseEntity<>(service.updateEntrega(entrega), HttpStatus.ACCEPTED);
    }
}