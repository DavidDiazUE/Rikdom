package co.edu.ue.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import co.edu.ue.entity.Cliente;
import co.edu.ue.jpa.IClienteJPA;

@Repository
public class ClienteDao implements IClienteDao {

    @Autowired
    private IClienteJPA jpa;

    @Override
    public List<Cliente> guardarCliente(Cliente cliente) {
        jpa.save(cliente);
        return listaCompleta();
    }

    @Override
    public Cliente actualizarCliente(Cliente cliente) {
        return jpa.save(cliente);
    }

    @Override
    public List<Cliente> listaCompleta() {
        return jpa.findAll();
    }

    @Override
    public Cliente buscarPorId(int id) {
        return jpa.findById(id).orElse(null);
    }
}
