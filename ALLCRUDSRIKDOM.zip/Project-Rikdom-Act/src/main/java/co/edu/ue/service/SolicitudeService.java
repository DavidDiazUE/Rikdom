package co.edu.ue.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.edu.ue.dao.ISolicitudeDao;
import co.edu.ue.entity.Solicitude;

@Service
public class SolicitudeService implements ISolicitudeService {

    @Autowired
    private ISolicitudeDao dao;

    @Override
    public List<Solicitude> addSolicitude(Solicitude solicitude) {
        return dao.guardarSolicitude(solicitude);
    }

    @Override
    public Solicitude updateSolicitude(Solicitude solicitude) {
        return dao.actualizarSolicitude(solicitude);
    }

    @Override
    public List<Solicitude> listAll() {
        return dao.listaCompleta();
    }

    @Override
    public Solicitude findById(int id) {
        return dao.buscarPorId(id);
    }
}