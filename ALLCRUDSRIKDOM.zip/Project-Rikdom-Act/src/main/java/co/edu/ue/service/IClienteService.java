package co.edu.ue.service;

import java.util.List;
import co.edu.ue.entity.Cliente;

public interface IClienteService {
    List<Cliente> addCliente(Cliente cliente);
    Cliente updateCliente(Cliente cliente);
    List<Cliente> listAll();
    Cliente findById(int id);
}
