package co.edu.ue.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import co.edu.ue.entity.TarjetasCredito;
import co.edu.ue.jpa.ITarjetasCreditoJPA;

@Repository
public class TarjetasCreditoDao implements ITarjetasCreditoDao {

    @Autowired
    private ITarjetasCreditoJPA jpa;

    @Override
    public List<TarjetasCredito> guardarTarjetaCredito(TarjetasCredito tarjetaCredito) {
        jpa.save(tarjetaCredito);
        return listaCompleta();
    }

    @Override
    public TarjetasCredito actualizarTarjetaCredito(TarjetasCredito tarjetaCredito) {
        return jpa.save(tarjetaCredito);
    }

    @Override
    public List<TarjetasCredito> listaCompleta() {
        return jpa.findAll();
    }

    @Override
    public TarjetasCredito buscarPorId(int id) {
        return jpa.findById(id).orElse(null);
    }
}