package co.edu.ue.dao;

import java.util.List;
import co.edu.ue.entity.TarjetasCredito;

public interface ITarjetasCreditoDao {
    List<TarjetasCredito> guardarTarjetaCredito(TarjetasCredito tarjetaCredito);
    TarjetasCredito actualizarTarjetaCredito(TarjetasCredito tarjetaCredito);
    List<TarjetasCredito> listaCompleta();
    TarjetasCredito buscarPorId(int id);
}